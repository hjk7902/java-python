package com.example.myapp;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class RestReqController {

    @RequestMapping("/test_req")
    public String testRestRequest(Model model) {
        try {
            URL url = new URL("http://192.168.60.128:5000/test1?data=Hello");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            InputStream in = con.getInputStream();
            InputStreamReader reader = new InputStreamReader(in, "UTF-8");
            BufferedReader response = new BufferedReader(reader);
            String str = null;
            StringBuffer buff = new StringBuffer();
            while ((str = response.readLine()) != null) {
                buff.append(str + "\n");
            }
            String data = buff.toString().trim();
            System.out.println("reqResult : " + data);
            model.addAttribute("reqResult", data);
        }catch(Exception e) {
            e.printStackTrace();
        }
        return "result1";
    }
    
    @RequestMapping("/test_req_image")
    public String testRestRequestImage(MultipartFile file, String data, Model model) {
        try {
            URL url = new URL("http://192.168.60.128:5000/test_img");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();

            String boundary = UUID.randomUUID().toString();
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);

            OutputStream out = con.getOutputStream();
            DataOutputStream request = new DataOutputStream(out);
            request.writeBytes("--" + boundary + "\r\n");
            request.writeBytes("Content-Disposition: form-data; name=\"data\"\r\n\r\n"); // 파라미터 data를 전송함 
            request.writeBytes(data + "\r\n");

            request.writeBytes("--" + boundary + "\r\n");
            request.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" + file.getOriginalFilename() + "\"\r\n\r\n");
            request.write(file.getBytes());
            request.writeBytes("\r\n");

            request.writeBytes("--" + boundary + "--\r\n");
            request.flush();
            int respCode = con.getResponseCode();

            // 요청 결과 코드에 따라 처리
            switch(respCode) {
            case 200:
                System.out.println("OK");
                break;
            case 301:
            case 302:
            case 307:
                System.out.println("Redirect");
                break;
            default:
                //do something
            }
            
            // 요청 후 응답 결과를 받기 위한 코드 
            InputStream in = con.getInputStream();
            InputStreamReader reader = new InputStreamReader(in, "UTF-8");
            BufferedReader response = new BufferedReader(reader);
            String str = null;
            StringBuffer buff = new StringBuffer();
            while ((str = response.readLine()) != null) {
                buff.append(str + "\n");
            }
            String result = buff.toString().trim();

            // 결과 문자열을 Map 객체로 변환 
            ObjectMapper mapper = new ObjectMapper();
            Map<String, String> map = mapper.readValue(result, Map.class);
            System.out.println(map.keySet());
            model.addAttribute("reqResult", map);
        }catch(Exception e) {
            e.printStackTrace();
        }
        return "result2";
    }
}
